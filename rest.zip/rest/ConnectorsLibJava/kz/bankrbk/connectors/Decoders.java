package kz.bankrbk.connectors;

import java.io.UnsupportedEncodingException;


public final class Decoders { 
	   
	private static final byte[] Win1251 = { (byte)0xbc, (byte)0xb3, (byte)0xbe, (byte)0xba, (byte)0xbf, (byte)0xa2, (byte)0x9d, (byte)0xb4, (byte)0x9e, (byte)0xa3, (byte)0xb2, (byte)0xbd, (byte)0xaa, (byte)0xaf, (byte)0xa1, (byte)0x8d, (byte)0xa5, (byte)0x8e };
	private static final char[] SrcChars = createSrcChars();
	private static final char[] DstChars = "әіңғүұқөһӘІҢҒҮҰҚӨҺ".toCharArray();
	
	private static char[] createSrcChars(){
		try {
			return new String(Win1251,"cp1251").toCharArray();
		} catch (UnsupportedEncodingException e) {
			// Можно дальше не работать
			throw new Error(e);
		}
	}
		
	public static String KazWinToUtf8(final String input) throws UnsupportedEncodingException {
        if (input==null || input.isEmpty()) return input;
        char[] ca = input.toCharArray();
        return KazWinToUtf8(ca);
    }
	
	public static String KazWinToUtf8(final char[] ca) throws UnsupportedEncodingException {
        int len = ca.length;
        if (len == 0) 
        	return null;
        for (int i = 0; i < ca.length; i++) {
        	for(int j=0; j < SrcChars.length; j++){
        		if(ca[i]==SrcChars[j]){
        			ca[i]=DstChars[j];
        		}
        	}
        }
        return new String(ca);
    }
	
	public static String Utf8ToKazWin(final String input){
		if (input==null || input.isEmpty()) return input;
		char[] ca = input.toCharArray();
		for (int i = 0; i < ca.length; i++) {
        	for(int j=0; j < DstChars.length; j++){
        		if(ca[i]==DstChars[j]){
        			ca[i]=SrcChars[j];
        		}
        	}
        }
        return new String(ca);
	}

}
