package kz.bankrbk.connectors;

import java.io.UnsupportedEncodingException;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbXMLNSC;

public class Request {
	private MbElement id;
	private MbElement type;
	private MbElement operation;
	private MbElement system;
	private MbElement messageBody;
	private MbElement requestElement;
	private String Body;
	
	public Request(MbMessage inMessage) throws MbException, UnsupportedEncodingException{
		this.messageBody = inMessage.getRootElement().getLastChild();
		this.Body = new String(this.messageBody.toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0) , "UTF-8");
		this.requestElement = this.messageBody.getFirstElementByPath("root/request");
		if (this.requestElement!=null){
			this.id = requestElement.getFirstElementByPath("id");
			this.type = requestElement.getFirstElementByPath("type");
			this.operation = requestElement.getFirstElementByPath("operation");
			this.system = requestElement.getFirstElementByPath("system");
		}
	}
	
	public String getBody(){
		return this.Body;
	}
	public MbElement getMessageBody(){
		return this.messageBody;
	}
	public String getID() throws MbException{
		return this.id == null ? "" : this.id.getValueAsString();
	}
	public String getType() throws MbException{
		return this.type == null ? "" : this.type.getValueAsString();
	}
	public String getOperation() throws MbException{
		return this.operation == null ? "" : this.operation.getValueAsString();
	}
	public String getSystem() throws MbException{
		return this.system == null ? "" : this.system.getValueAsString();
	}
	public String getTypeOperation() throws MbException{
		return getType() + "-" + getOperation();
	}

}
