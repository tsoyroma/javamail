package kz.bankrbk.connectors;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Types;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class Hermes_API_Procedure extends MbJavaComputeNode {
	
	private final String CON_NAME = "IBSO";
	private static final String PROC_NAME="begin IBS.HERMES_API(?, ?); end;";

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbMessage inMessage = inAssembly.getMessage();

		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);

		try {
			byte[] messageBytes = inMessage.getRootElement().getLastChild().toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0);
			String messageBody = new String(messageBytes,"UTF-8");
			MbElement omroot = outMessage.getRootElement();	
			processHermes(messageBody,3,omroot);
		} catch (MbException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new MbUserException(this, "evaluateHermes4()", "", "", e.toString(), null);
		}

		out.propagate(outAssembly);
	}
	
	/*@Override
	public void onInitialize() {
		Properties hermesProperties = getHermesProperties();
		if(hermesProperties!=null){
			disableLog = hermesProperties.getProperty("disableLog"); 
			disableEncode = hermesProperties.getProperty("disableEncode"); 
		}
	}*/
	
	/*private synchronized Properties getHermesProperties(){
		try {
			Properties prop = new Properties();
			try(FileInputStream input = new FileInputStream("/home/IIB/Configs/Core/hermes.properties")){
				prop.load(input);	
				input.close();
			}
			//BrokerProxy bp = BrokerProxy.getLocalInstance();
			//short c = 0;
			//while(!bp.hasBeenPopulatedByBroker()) {
				//c++;
				//Thread.sleep(100);
				//if(c > 3) throw new Exception("hasNotBeenPopulatedByBroker");
			//}
			//ConfigurableService udcs = bp.getConfigurableService("UserDefined", "HermesAPI");
			//return prop;
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.toString());
			return null;
		}
	}*/
	
	private void processHermes(String messageBody,  int recursiveCalls, MbElement root) throws MbException{	
		Connection con = getJDBCType4Connection(CON_NAME, JDBC_TransactionType.MB_TRANSACTION_AUTO);
		try(
			CallableStatement st = con.prepareCall(PROC_NAME)){
			st.setQueryTimeout(3600);
			SQLXML request = con.createSQLXML();
			
			request.setString(messageBody);
			st.setSQLXML(1, request);
			st.registerOutParameter(2,Types.SQLXML);
			st.execute();
			SQLXML response = st.getSQLXML(2);
			st.close();
			
			writeMessageBodyAsString(response,root);
			try {if (request!=null) request.free();}  finally {request=null;}
			try {if (response!=null) response.free();}  finally {response=null;}
			
			con.close();
		}
		catch(SQLException e){
			throw new MbUserException(this, "processHermes4()", "", "", e.toString(), null);
		}
	}
	
	private void writeMessageBodyAsString(SQLXML resp, MbElement root) throws MbException{
		try{
			root.createElementAsLastChildFromBitstream(Decoders.KazWinToUtf8(resp.getString()).getBytes("UTF-8"), MbXMLNSC.PARSER_NAME, "", "", "", 546, 1208, 0);
		}
		catch(Exception e){
			throw new MbUserException(this, "writeMessageBody4()", "", "", e.toString(), null);
		}
	}
	
	/*private void writeMessageBody(SQLXML resp, MbElement root) throws SQLException, MbException{		
		try( BufferedReader rd =new BufferedReader(resp.getCharacterStream(),SIZE) ){
			char [] buffer = new char[SIZE]; 
			int i = 0;
			while( (i=rd.read(buffer,0,buffer.length)) != -1 ){
				if (i<buffer.length) {
					root.createElementAsLastChildFromBitstream(Decoders.KazWinToUtf8(Arrays.copyOf(buffer,i)).getBytes(), MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);
				}
				else {
					root.createElementAsLastChildFromBitstream(Decoders.KazWinToUtf8(buffer).getBytes(), MbXMLNSC.PARSER_NAME, "", "", "", 0, 0, 0);
				}
			}
		}
		catch(IOException e){
			throw new MbUserException(this, "writeMessageBodyHermes()", "", "", e.toString(), null);
		}
	}*/


}
