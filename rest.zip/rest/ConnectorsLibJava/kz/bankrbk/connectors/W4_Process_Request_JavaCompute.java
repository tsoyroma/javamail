package kz.bankrbk.connectors;

import java.sql.Connection;
import java.sql.SQLException;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

public class W4_Process_Request_JavaCompute extends MbJavaComputeNode {
	
	private static final String PROC_NAME = "BEGIN ows.opt_integration.mi_process_request(:request,:response); END;";
	private static final String POOLED_SERVICE_NAME = "OPENWAY";
	private static final String NON_POOLED_SERVICE_NAME = "OPENWAYNONPOOL";
	

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");
		
		boolean propogateAlt = true;
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);
		int statementTimeout = getStatementTimeOut();
		String serviceName = usePooledConnection() ? POOLED_SERVICE_NAME : NON_POOLED_SERVICE_NAME;

		try {
			copyMessageHeaders(inMessage, outMessage);
			MbElement msg = inMessage.getRootElement().getLastChild();
			if (msg==null) 
				throw new MbUserException(this, "Openway-evaluate()", "", "", "Message MbElement is null", null);
			String request = new String(msg.toBitstream(MbXMLNSC.PARSER_NAME, "", "", 546, 1208, 0) , "UTF-8");
			MbElement omroot = outMessage.getRootElement();			
			Connection con = this.getJDBCType4Connection(serviceName, JDBC_TransactionType.MB_TRANSACTION_AUTO); // Do not close connection, Broker handles them//
			if (con == null)
				throw new MbUserException(this, "getBrokerConnection("+serviceName+")", "", "", "BrokerConnection is null", null);
			
			OracleInterop.setApplicationInfo(con, getExecutionServerName(), getPrettyMessageFlowName(), 1);
			
			String response = null;
			try {
				response = OracleInterop.executeInteropProcedure(con, request, PROC_NAME, statementTimeout);
			}
			catch(SQLException se){
				OracleInterop.setEnvorimentSQLException(inAssembly, se);
				throw new MbUserException(this, "Openway Procedure Call", "", "", se.toString(), null);
			}
			
			if (response == null)
				throw new MbUserException(this, "Openway_Evaluate", "", "", "Openway Procedure Call returned null", null);
			
			writeMessageBody(response, omroot);
			
		} 
		catch (Exception e) {
			OracleInterop.notifyException(alt,inAssembly, e, serviceName, statementTimeout);
			OracleInterop.clearMessage(outMessage);
			outMessage = null;	
			if(e instanceof MbException)
				throw (MbException)e;
			else if(e instanceof RuntimeException)
				throw (RuntimeException)e;
			else
				throw new MbUserException(this, "evaluateOpenway()", "", "", e.toString(),null);		
		}
		
		if (propogateAlt){
			outMessage.finalizeMessage(MbMessage.FINALIZE_NONE);
			alt.propagate(outAssembly);
		}
		
		outMessage.finalizeMessage(MbMessage.FINALIZE_NONE);
		out.propagate(outAssembly,true);
	}	

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) 
		{
			outRoot.addAsLastChild(header.copy());
			header = header.getNextSibling();
		}
	}
	
	private void writeMessageBody(final String resp, final MbElement root) throws MbException {	
		try {
			OracleInterop.writeMessageBodyAsString(resp, false, root);
		}
		catch(Exception e){
			throw new MbUserException(this, "Openway writeMessageBody", "", "", e.toString(), null);
		}
		
	}
	
	private boolean usePooledConnection(){
		boolean pc = true;
		try {
			pc = Boolean.parseBoolean(this.getUserDefinedAttribute("UsePooledConnection").toString());
		}
		catch(Exception e){
			pc = true;
		}
		return pc; 
	}
	
	private int getStatementTimeOut(){
		int timeOut=120;
		try {
			timeOut=Integer.parseInt(this.getUserDefinedAttribute("TimeOut").toString());
			if (timeOut<=0) 
				timeOut=120;
		}
		catch(Exception e){
			timeOut=120;
		}
		return timeOut; 
	}
	
	private String getExecutionServerName(){
		try {
			return this.getExecutionGroup().getName();
		}
		catch(Exception e){
			return "n/a";
		}
	}
	
	private String getPrettyMessageFlowName(){
		try {
			String[] a = this.getMessageFlow().getName().split("\\.");
			return a[a.length-1];
		}
		catch(Exception e){
			return "n/a";
		}	
	}

}
