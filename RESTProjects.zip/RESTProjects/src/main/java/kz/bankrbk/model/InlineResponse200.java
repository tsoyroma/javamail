package kz.bankrbk.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.*;
/**
 * InlineResponse200
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-06-20T09:14:57.609Z")

public class InlineResponse200   {
  @JsonProperty("no")
  private String no = null;

  @JsonProperty("phone")
  private String phone = null;

  @JsonProperty("status")
  private String status = null;

  public InlineResponse200 no(String no) {
    this.no = no;
    return this;
  }

   /**
   * Get no
   * @return no
  **/
  @ApiModelProperty(example = "test", value = "")
  public String getNo() {
    return no;
  }

  public void setNo(String no) {
    this.no = no;
  }

  public InlineResponse200 phone(String phone) {
    this.phone = phone;
    return this;
  }

   /**
   * Get phone
   * @return phone
  **/
  @ApiModelProperty(example = "77018452874", value = "")
  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public InlineResponse200 status(String status) {
    this.status = status;
    return this;
  }

   /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(example = "off", value = "")
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InlineResponse200 inlineResponse200 = (InlineResponse200) o;
    return Objects.equals(this.no, inlineResponse200.no) &&
        Objects.equals(this.phone, inlineResponse200.phone) &&
        Objects.equals(this.status, inlineResponse200.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(no, phone, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InlineResponse200 {\n");
    
    sb.append("    no: ").append(toIndentedString(no)).append("\n");
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

